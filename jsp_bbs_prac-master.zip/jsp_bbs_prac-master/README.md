# jsp_bbs_prac

* [나동빈-JSP 게시판 강좌](https://www.youtube.com/watch?v=wEIBDHfoMBg&list=PLRx0vPvlEmdAZv_okJzox5wj2gG_fNh_6)를 참고해서 만들어본 JSP 게시판 코드입니다

## 배운 것

* 세션으로 로그인 여부 확인
* DAO를 
* JSP - jdbc 사용 방법
* mySQL로 회원가입과 게시판 테이블 생성
* CRUD 연습

## 개선할 것

* 데이터베이스 로그인/패스워드 gitignore
* mySQL 한글 인코딩 문제
